// Update main image on thumbnail click
function updateMainImage(thumbnail) {
  const mainImage = document.getElementById('main-product-image');
  mainImage.src = thumbnail.src;
}

// Modal logic
const sizeChartBtn = document.getElementById('sizeChartBtn');
const sizeChartModal = document.getElementById('sizeChartModal');
const closeModal = document.querySelector('.close');

sizeChartBtn.addEventListener('click', () => {
  sizeChartModal.style.display = 'block';
});

closeModal.addEventListener('click', () => {
  sizeChartModal.style.display = 'none';
});

window.addEventListener('click', (e) => {
  if (e.target === sizeChartModal) {
    sizeChartModal.style.display = 'none';
  }
});

window.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    sizeChartModal.style.display = 'none';
  }
});

// Variant logic
const colorButtons = document.querySelectorAll('.color-swatch');
const selectedColor = document.getElementById('selectedColor');
const mainImage = document.getElementById('main-product-image');

colorButtons.forEach(button => {
  button.addEventListener('click', () => {
    colorButtons.forEach(btn => btn.classList.remove('selected'));
    button.classList.add('selected');

    selectedColor.textContent = button.dataset.color;
    mainImage.src = button.dataset.img;
  });
});

const sizeSelect = document.getElementById('size');
const selectedSize = document.getElementById('selectedSize');

sizeSelect.addEventListener('change', () => {
  selectedSize.textContent = sizeSelect.value || 'None';
});
// Compare Colours Feature
const compareBtn = document.getElementById('compareBtn');
const compareModal = document.getElementById('compareModal');
const closeCompare = document.querySelector('.close-compare');
const compareSwatches = document.getElementById('compareSwatches');

let selectedColors = [];

colorButtons.forEach(button => {
  button.addEventListener('dblclick', () => {
    const color = button.dataset.color;
    const bg = button.style.background;

    // Add color if not already selected
    if (!selectedColors.find(c => c.color === color)) {
      selectedColors.push({ color, bg });
    }

    // Limit to 4 colors
    if (selectedColors.length > 4) {
      selectedColors.shift();
    }
  });
});

compareBtn.addEventListener('click', () => {
  compareSwatches.innerHTML = '';
  selectedColors.forEach(c => {
    const swatch = document.createElement('div');
    swatch.classList.add('compare-swatch');
    swatch.style.background = c.bg;
    compareSwatches.appendChild(swatch);
  });
  compareModal.style.display = 'block';
});

closeCompare.addEventListener('click', () => {
  compareModal.style.display = 'none';
});

window.addEventListener('click', (e) => {
  if (e.target === compareModal) {
    compareModal.style.display = 'none';
  }
});
// Tab switching
const tabButtons = document.querySelectorAll(".tab-button");
const tabContents = document.querySelectorAll(".tab-content");

tabButtons.forEach(button => {
  button.addEventListener("click", () => {
    const target = button.dataset.tab;

    tabButtons.forEach(btn => btn.classList.remove("active"));
    tabContents.forEach(tab => tab.classList.remove("active"));

    button.classList.add("active");
    document.getElementById(target).classList.add("active");
  });
});
